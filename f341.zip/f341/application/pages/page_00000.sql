prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_user_interface_id=>wwv_flow_imp.id(2120625061141399928)
,p_name=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'DIAS.FDA'
,p_last_upd_yyyymmddhh24miss=>'20230606090659'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2476870569565325781)
,p_name=>'AtualizaToken'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2476870716071325782)
,p_event_id=>wwv_flow_imp.id(2476870569565325781)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sessionTime NUMBER;',
'BEGIN',
'    apex_debug.enable(); ',
'',
'    l_sessionTime := PKG_AUTH.calc_time(:G_TOKEN_TIME);',
'',
'    IF l_sessionTime > 600 THEN',
'        apex_debug.message(''Token atualizado'');',
'        PKG_AUTH.get_refreshed_token(:G_REFRESH_TOKEN, :APP_URL_TOKEN, :APP_CLIENT_ID, :APP_CLIENT_SECRET);',
'    END IF;',
'',
'',
'END;'))
,p_attribute_02=>'G_REFRESH_TOKEN'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
