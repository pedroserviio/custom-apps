prompt --workspace/remote_servers/corporativo_api
begin
--   Manifest
--     REMOTE SERVER: corporativo_api
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(2189798478481754292)
,p_name=>'corporativo_api'
,p_static_id=>'corporativo_api'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('corporativo_api'),'http://corporativo-rest-corporativo-rest-hom.apps.ocphom.pf.gov.br/corporativo/api/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('corporativo_api'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('corporativo_api'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('corporativo_api'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('corporativo_api'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
