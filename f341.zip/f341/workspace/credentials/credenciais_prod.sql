prompt --workspace/credentials/credenciais_prod
begin
--   Manifest
--     CREDENTIAL: credenciais_prod
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(744024646529969461)
,p_name=>'credenciais_prod'
,p_static_id=>'credenciais_prod'
,p_authentication_type=>'BASIC'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
