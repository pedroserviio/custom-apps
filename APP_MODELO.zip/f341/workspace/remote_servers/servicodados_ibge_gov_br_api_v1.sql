prompt --workspace/remote_servers/servicodados_ibge_gov_br_api_v1
begin
--   Manifest
--     REMOTE SERVER: servicodados-ibge-gov-br-api-v1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(299137475353899411)
,p_name=>'servicodados-ibge-gov-br-api-v1'
,p_static_id=>'servicodados_ibge_gov_br_api_v1'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('servicodados_ibge_gov_br_api_v1'),'http://servicodados.ibge.gov.br/api/v1/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('servicodados_ibge_gov_br_api_v1'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('servicodados_ibge_gov_br_api_v1'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('servicodados_ibge_gov_br_api_v1'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('servicodados_ibge_gov_br_api_v1'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
