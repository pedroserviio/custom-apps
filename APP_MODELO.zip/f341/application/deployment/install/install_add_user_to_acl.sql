prompt --application/deployment/install/install_add_user_to_acl
begin
--   Manifest
--     INSTALL: INSTALL-add user to ACL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1086310552623556086)
,p_install_id=>wwv_flow_imp.id(2224544913953427135)
,p_name=>'add user to ACL'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    username VARCHAR(50);',
'BEGIN',
'',
'    SELECT USER_NAME INTO username FROM APEX_WORKSPACE_SESSIONS;',
'',
'    APEX_ACL.ADD_USER_ROLE (',
'        p_application_id  => :APP_ID,',
'        p_user_name       => username,',
'        p_role_static_id  => ''ADMINISTRATOR''',
'    );',
'',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
