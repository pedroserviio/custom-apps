prompt --application/shared_components/data_profiles/estados
begin
--   Manifest
--     DATA PROFILE: estados
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>'estados'
,p_format=>'JSON'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(2005547915607227316)
,p_data_profile_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>'ID'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(2005547525425227315)
,p_data_profile_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>'Distrito'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'nome'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(2005548459472227316)
,p_data_profile_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>unistr('Munic\00EDpio')
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'municipio.nome'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(2005548191191227316)
,p_data_profile_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>'Micro Regiao'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'municipio.microrregiao.nome'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(2005548724868227316)
,p_data_profile_id=>wwv_flow_imp.id(2005547415626227314)
,p_name=>'Regiao Imediata'
,p_sequence=>5
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'municipio.regiao-imediata.nome'
);
wwv_flow_imp.component_end;
end;
/
