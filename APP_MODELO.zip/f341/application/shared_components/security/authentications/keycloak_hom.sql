prompt --application/shared_components/security/authentications/keycloak_hom
begin
--   Manifest
--     AUTHENTICATION: keycloak_hom
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(2516193333598057024)
,p_name=>'keycloak_hom'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(3066716547119982648)
,p_attribute_02=>'OAUTH2'
,p_attribute_04=>'https://sistemashom.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/auth'
,p_attribute_05=>'https://sistemashom.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/token'
,p_attribute_06=>'https://sistemashom.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/userinfo'
,p_attribute_07=>'profile'
,p_attribute_09=>'preferred_username'
,p_attribute_10=>'preferred_username'
,p_attribute_11=>'Y'
,p_attribute_12=>'BASIC_AND_CLID'
,p_attribute_13=>'Y'
,p_attribute_14=>'G_USERNAME'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure load_dynamic_c_roles as ',
'',
'    l_token varchar2(5000); ',
'',
'    l_refresh_token varchar2(5000);',
'',
'    l_token_decoded apex_jwt.t_token; ',
'',
'    l_email varchar2(200);',
'',
'    v_app_corporativo_url varchar2(256);',
'',
' ',
'',
'begin ',
'',
'   apex_debug.enable(); ',
'',
'    l_token := apex_json.get_varchar2(''access_token''); ',
'',
'    l_refresh_token := apex_json.get_varchar2(''refresh_token''); ',
'',
'    apex_debug.message(''token ---> '' || l_token); ',
'',
'    apex_debug.message(''refresh_token ---> '' || l_refresh_token); ',
' ',
'    l_token_decoded := apex_jwt.decode(p_value => l_token); ',
'',
'    apex_debug.message(''------> '' || l_token_decoded.payload); ',
'',
'    apex_util.set_session_state(''G_TOKEN_CODED'', (''Bearer '' || l_token));',
'',
'    apex_util.set_session_state(''G_REFRESH_TOKEN'', l_refresh_token);',
'',
'    apex_util.set_session_state(''G_TOKEN'', l_token);',
'',
'    apex_util.set_session_state(''G_ACCESS_TOKEN_PAYLOAD'', l_token_decoded.payload);',
'',
'    apex_util.set_session_state(''G_TOKEN_TIME'', TO_CHAR(TO_CHAR(sysdate,''sssss'')));',
'',
'end; '))
,p_invalid_session_type=>'LOGIN'
,p_logout_url=>'https://sistemashom.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/logout?redirect_uri=&APP_URL.'
,p_post_auth_process=>'load_dynamic_c_roles'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
