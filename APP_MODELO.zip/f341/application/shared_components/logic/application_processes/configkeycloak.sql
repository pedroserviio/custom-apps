prompt --application/shared_components/logic/application_processes/configkeycloak
begin
--   Manifest
--     APPLICATION PROCESS: ConfigKeycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(2516248016547474393)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ConfigKeycloak'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    current_keycloak varchar2(100);',
'    workspace_name varchar(100);',
'    application_name varchar(100);',
'BEGIN',
'',
'    SELECT AUTHENTICATION_SCHEME_NAME INTO current_keycloak FROM APEX_APPLICATION_AUTH WHERE APPLICATION_ID = :APP_ID AND IS_CURRENT_AUTHENTICATION = ''Y'';',
'    SELECT PATH_PREFIX INTO workspace_name FROM APEX_WORKSPACES;',
'    SELECT APPLICATION_NAME INTO application_name FROM APEX_APPLICATIONS WHERE APPLICATION_ID = :APP_ID;',
'',
'    :APP_URL := ''https://appsdev.pf.gov.br/r/'' || LOWER(workspace_name) || ''/'' || LOWER(:APP_ALIAS) || ''/home?'';',
'    :APP_NAME := UPPER(application_name);',
'',
'    IF current_keycloak = ''keycloak_dev'' THEN',
'',
'        :APP_CLIENT_ID := ''apex_dev'';',
'        :APP_CLIENT_SECRET := ''a57dc73f-20c7-42d2-99f6-50732790e37b'';	',
'        :APP_CORPORATIVO_URL := ''http://corporativo-rest-corporativo-rest-dev.apps.ocpdesenv.pf.gov.br/corporativo/api/'';',
'        :APP_URL_TOKEN := ''https://authdesenv.pf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/token'';',
'        PKG_AUTH.get_user(:G_USERNAME, :APP_CORPORATIVO_URL);',
'',
'    ELSIF current_keycloak = ''keycloak_hom'' THEN',
'',
'        :APP_CLIENT_ID := ''apex_hom'';',
'        :APP_CLIENT_SECRET := ''dd782ffd-c3b5-4632-9235-bb0e2fb3bcee'';	',
'        :APP_CORPORATIVO_URL := ''http://corporativo-rest-corporativo-rest-hom.apps.ocphom.pf.gov.br/corporativo/api/'';',
'        :APP_URL_TOKEN := ''https://sistemashom.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/token'';    ',
'        PKG_AUTH.get_user(:G_USERNAME, :APP_CORPORATIVO_URL);',
'',
'    ELSIF current_keycloak = ''keycloak_prod'' THEN',
'',
'        :APP_CLIENT_ID := ''apex_prod'';',
'        :APP_CLIENT_SECRET := ''f6fc688b-a2eb-48e6-964d-cd6556ede0ca'';	',
'        :APP_CORPORATIVO_URL := ''https://sistemas.dpf.gov.br/corporativo/api/'';',
'        :APP_URL_TOKEN := ''https://sistemas.dpf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/token'';    ',
'        PKG_AUTH.get_user(:G_USERNAME, :APP_CORPORATIVO_URL);',
'        ',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
