prompt --application/shared_components/files/css_frontline_header_css
begin
--   Manifest
--     APP STATIC FILES: 341
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E70662D75692D6865616465722D6272616E642D737570207B0D0A636F6C6F723A20236632623634653B0D0A666F6E742D66616D696C793A204F70656E2053616E7320426F6C642C2073616E732D73657269663B0D0A666F6E742D73697A653A20313070';
wwv_flow_imp.g_varchar2_table(2) := '783B0D0A766572746963616C2D616C69676E3A2073757065723B0D0A7D0D0A2E70662D75692D6865616465722D6272616E642D6E616D65207B0D0A636F6C6F723A20236666663B0D0A666F6E742D66616D696C793A204F70656E2053616E7320426F6C64';
wwv_flow_imp.g_varchar2_table(3) := '2C2073616E732D73657269663B0D0A666F6E742D73697A653A20323070783B0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(1991038000907329141)
,p_file_name=>'css/frontline_header.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
