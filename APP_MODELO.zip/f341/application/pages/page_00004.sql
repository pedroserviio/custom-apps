prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>51049083991370133
,p_default_application_id=>341
,p_default_id_offset=>2032968942574380351
,p_default_owner=>'PEDRO_SERVIO'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_imp.id(2120625061141399928)
,p_name=>'Consulta Visita'
,p_alias=>'CONSULTA-VISITA'
,p_step_title=>'Consulta Visita'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'DIAS.FDA'
,p_last_upd_yyyymmddhh24miss=>'20230606180659'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2493610800379160562)
,p_plug_name=>'Consulta Visita'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2120523475628399872)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tp.NR_CPF,',
'    tp.NO_PESSOA,',
'    tv.DT_CHEGADA,',
'    tv.DT_SAIDA,',
'    tv.TP_VISITA,',
'    tv.ID_VISITA,',
'    tv.ID_VISITANTE',
' from TB_VISITANTE tp,',
'    TB_VISITA tv ',
' where tv.ID_VISITANTE=tp.ID_VISITANTE'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Consulta Visita'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2493610918250160562)
,p_name=>'Consulta Visita'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'ID_VISITA'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:P6_ID_VISITA:\#ID_VISITA#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DIAS.FDA'
,p_internal_uid=>546522995035634215
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493613226975160566)
,p_db_column_name=>'ID_VISITA'
,p_display_order=>0
,p_column_identifier=>'F'
,p_column_label=>'Id Visita'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493611303536160563)
,p_db_column_name=>'NR_CPF'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Nr Cpf'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493611651158160564)
,p_db_column_name=>'NO_PESSOA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'No Pessoa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493612065096160564)
,p_db_column_name=>'DT_CHEGADA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Dt Chegada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493612512051160566)
,p_db_column_name=>'DT_SAIDA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Dt Saida'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493612880110160566)
,p_db_column_name=>'TP_VISITA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Tp Visita'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2493613669979160567)
,p_db_column_name=>'ID_VISITANTE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Id Visitante'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2493616529924162686)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5465287'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_VISITA:NR_CPF:NO_PESSOA:DT_CHEGADA:DT_SAIDA:TP_VISITA:ID_VISITANTE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2493615913823160574)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2120539858891399878)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2120437010338399830)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(2120602015766399909)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2493614151957160568)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2493610800379160562)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(2120600401379399908)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:6::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2493614523024160568)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2493610800379160562)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2493614949956160573)
,p_event_id=>wwv_flow_imp.id(2493614523024160568)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2493610800379160562)
);
wwv_flow_imp.component_end;
end;
/
