prompt --workspace/credentials/credenciais_dev
begin
--   Manifest
--     CREDENTIAL: credenciais_dev
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(1681362170512583136)
,p_name=>'credenciais_dev'
,p_static_id=>'credenciais_dev'
,p_authentication_type=>'BASIC'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
