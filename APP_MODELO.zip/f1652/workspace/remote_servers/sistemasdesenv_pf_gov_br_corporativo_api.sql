prompt --workspace/remote_servers/sistemasdesenv_pf_gov_br_corporativo_api
begin
--   Manifest
--     REMOTE SERVER: sistemasdesenv-pf-gov-br-corporativo-api
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(3333747275769224693)
,p_name=>'sistemasdesenv-pf-gov-br-corporativo-api'
,p_static_id=>'sistemasdesenv_pf_gov_br_corporativo_api'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('sistemasdesenv_pf_gov_br_corporativo_api'),'https://sistemasdesenv.pf.gov.br/corporativo/api/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('sistemasdesenv_pf_gov_br_corporativo_api'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('sistemasdesenv_pf_gov_br_corporativo_api'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('sistemasdesenv_pf_gov_br_corporativo_api'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('sistemasdesenv_pf_gov_br_corporativo_api'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
