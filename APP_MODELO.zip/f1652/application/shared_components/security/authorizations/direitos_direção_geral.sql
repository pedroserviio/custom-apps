prompt --application/shared_components/security/authorizations/direitos_direção_geral
begin
--   Manifest
--     SECURITY SCHEME: Direitos Direção Geral
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(3565058797194822317)
,p_name=>unistr('Direitos Dire\00E7\00E3o Geral')
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrator,Contributor,Reader'
,p_attribute_02=>'A'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
