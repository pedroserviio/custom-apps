prompt --application/shared_components/logic/application_processes/atualizatokenajax
begin
--   Manifest
--     APPLICATION PROCESS: AtualizaTokenAjax
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(3251245607466560000)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AtualizaTokenAjax'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    PKG_AUTH.get_refreshed_token(:G_REFRESH_TOKEN, :APP_URL_TOKEN, :APP_CLIENT_ID, :APP_CLIENT_SECRET);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
