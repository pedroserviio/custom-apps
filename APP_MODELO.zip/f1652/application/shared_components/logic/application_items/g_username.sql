prompt --application/shared_components/logic/application_items/g_username
begin
--   Manifest
--     APPLICATION ITEM: G_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(3378891868946374211)
,p_name=>'G_USERNAME'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
