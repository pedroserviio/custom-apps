prompt --application/shared_components/files/css_frontline_header_min_css
begin
--   Manifest
--     APP STATIC FILES: 1652
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E70662D75692D6865616465722D6272616E642D7375707B636F6C6F723A236632623634653B666F6E742D66616D696C793A4F70656E2053616E7320426F6C642C73616E732D73657269663B666F6E742D73697A653A313070783B766572746963616C2D';
wwv_flow_imp.g_varchar2_table(2) := '616C69676E3A73757065727D2E70662D75692D6865616465722D6272616E642D6E616D657B636F6C6F723A236666663B666F6E742D66616D696C793A4F70656E2053616E7320426F6C642C73616E732D73657269663B666F6E742D73697A653A32307078';
wwv_flow_imp.g_varchar2_table(3) := '7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(3249245887244154426)
,p_file_name=>'css/frontline_header.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
