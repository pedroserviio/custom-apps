prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 1652
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(3378830799394245015)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(3378690705498244948)
,p_default_dialog_template=>wwv_flow_imp.id(3378685423444244946)
,p_error_template=>wwv_flow_imp.id(3378675732208244942)
,p_printer_friendly_template=>wwv_flow_imp.id(3378690705498244948)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(3378675732208244942)
,p_default_button_template=>wwv_flow_imp.id(3378827788108245007)
,p_default_region_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_chart_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_form_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_reportr_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_tabform_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_wizard_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_menur_template=>wwv_flow_imp.id(3378767245620244977)
,p_default_listr_template=>wwv_flow_imp.id(3378755146371244973)
,p_default_irr_template=>wwv_flow_imp.id(3378750862357244971)
,p_default_report_template=>wwv_flow_imp.id(3378792769482244988)
,p_default_label_template=>wwv_flow_imp.id(3378825241409245005)
,p_default_menu_template=>wwv_flow_imp.id(3378829402495245008)
,p_default_calendar_template=>wwv_flow_imp.id(3378829500102245009)
,p_default_list_template=>wwv_flow_imp.id(3378809181372244996)
,p_default_nav_list_template=>wwv_flow_imp.id(3378820938987245002)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(3378820938987245002)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(3378815601410244999)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(3378703569567244954)
,p_default_dialogr_template=>wwv_flow_imp.id(3378700780864244953)
,p_default_option_label=>wwv_flow_imp.id(3378825241409245005)
,p_default_required_label=>wwv_flow_imp.id(3378826566737245006)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_imp.id(3378815211914244999)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/21.2/')
,p_files_version=>65
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
