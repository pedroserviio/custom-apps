prompt --application/deployment/install/install_create_package
begin
--   Manifest
--     INSTALL: INSTALL-create package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3293473959760495371)
,p_install_id=>wwv_flow_imp.id(3482772300682272234)
,p_name=>'create package'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE PACKAGE "PKG_AUTH" ',
'AS',
'  PROCEDURE GET_REFRESHED_TOKEN (refresh_token VARCHAR2, APP_URL_TOKEN VARCHAR2, APP_CLIENT_ID VARCHAR2, APP_CLIENT_SECRET VARCHAR2);',
'  PROCEDURE GET_USER(user VARCHAR2, APP_CORPORATIVO_URL VARCHAR2);',
'  FUNCTION CALC_TIME(argTimestamp NUMBER) RETURN NUMBER;',
'  FUNCTION SISEG_AUTHORIZATION(p_role VARCHAR2) RETURN BOOLEAN;',
'END PKG_AUTH;',
'/',
'',
'',
'CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PKG_AUTH" --Corpo',
'AS',
'	PROCEDURE GET_REFRESHED_TOKEN (refresh_token VARCHAR2, ',
'	                               APP_URL_TOKEN VARCHAR2, ',
'	                               APP_CLIENT_ID VARCHAR2, ',
'	                               APP_CLIENT_SECRET VARCHAR2)',
'    IS',
'        l_blob      BLOB;',
'        l_body      CLOB;',
'    BEGIN',
'        apex_web_service.g_request_headers(1).name := ''Content-Type'';',
'        apex_web_service.g_request_headers(1).value := ''application/x-www-form-urlencoded'';',
'        l_body := ''grant_type=refresh_token&client_id=''||APP_CLIENT_ID||''&client_secret=''||APP_CLIENT_SECRET||''&refresh_token=''||refresh_token;',
'        ',
'        l_blob := apex_web_service.make_rest_request_b(',
'            p_url            => APP_URL_TOKEN,',
'            p_http_method    => ''POST'',',
'            p_body           => l_body,',
'            p_transfer_timeout => 3600',
'        );',
'        apex_json.parse(TO_CHAR(l_blob));',
'        apex_util.set_session_state(''G_REFRESH_TOKEN'', apex_json.get_varchar2(''refresh_token''));',
'        apex_util.set_session_state(''G_TOKEN_CODED'', (''Bearer '' || apex_json.get_varchar2(''access_token'')));',
'        apex_util.set_session_state(''G_TOKEN'', apex_json.get_varchar2(''access_token''));',
'        apex_util.set_session_state(''G_TOKEN_TIME'', TO_CHAR(TO_CHAR(sysdate,''sssss'')));',
'        htp.p(''{"response": "sucess"}'');',
'    END;',
'		',
'	 --************',
'	PROCEDURE GET_USER (user VARCHAR2,',
'	                    APP_CORPORATIVO_URL VARCHAR2)',
'	IS',
'	    access_token    STRING(32767);',
'	    l_blob          BLOB;',
'	    r_json          STRING(32767);',
'	BEGIN',
'	    access_token := apex_util.get_session_state(''G_TOKEN'');',
'        l_blob := apex_web_service.make_rest_request_b(',
'          p_url            => APP_CORPORATIVO_URL||''usuarios/''||user||''?access_token=''||access_token,',
'          p_http_method    => ''GET'',',
'          p_transfer_timeout => 3600',
'        );',
'	    ',
'	    r_json := TO_CHAR(l_blob);',
'	    apex_json.parse(r_json);',
'	    apex_util.set_session_state(''G_CPF'', apex_json.get_varchar2(''dadosPessoais.cpfCnpj''));',
'        apex_util.set_session_state(''G_NOME'', apex_json.get_varchar2(''dadosPessoais.nome''));',
'	    apex_util.set_session_state(''G_LOTACAO_USER'', apex_json.get_varchar2(''unidadeExercicio.sigla''));',
'	    apex_util.set_session_state(''G_USER_JSON'', r_json);',
'	END;',
'		',
'		',
'	 ---*************',
'	FUNCTION CALC_TIME (argTimestamp NUMBER)',
'	RETURN NUMBER',
'	IS ',
'        currentTime NUMBER := TO_CHAR(sysdate,''sssss'');',
'	BEGIN',
'	    RETURN  currentTime - argTimestamp;',
'	END;',
'	---******************************************',
'    ',
'	FUNCTION SISEG_AUTHORIZATION (p_role VARCHAR2) ',
'	return BOOLEAN ',
'	is ',
'	    l_numroles  NUMBER; ',
'	BEGIN ',
'	    apex_debug.message(''G_ACCESS_TOKEN_PAYLOAD ----> '' || apex_util.get_session_state(''G_ACCESS_TOKEN_PAYLOAD'')); ',
'	    apex_json.parse(apex_util.get_session_state(''G_ACCESS_TOKEN_PAYLOAD'')); ',
unistr('	    -- se n\00E3o possui roles para o nosso aplicativo, retorno false '),
'	    IF apex_json.does_exist(p_path=>''resource_access.apex_dev.roles'') = FALSE THEN ',
unistr('	        apex_debug.message(''n\00E3o tem roles''); '),
'	        return false; ',
'	    end if; ',
unistr('	    -- percorro array de roles at\00E9 encontrar a role desejada '),
'	    l_numroles := apex_json.get_count(p_path=>''resource_access.apex_dev.roles''); ',
'	    FOR i IN 1 .. l_numroles LOOP ',
'	        apex_debug.message(''encontrada role '' || apex_json.get_varchar2(''resource_access.apex_dev.roles[%d]'', i)); ',
'	        IF p_role = apex_json.get_varchar2(''resource_access.apex_dev.roles[%d]'', i) THEN ',
'	            RETURN TRUE; ',
'	        END if; ',
'	    END LOOP; ',
unistr('	    -- n\00E3o encontrou role, false '),
'	    return FALSE; ',
'	END;',
'    ',
'END;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3293474096851495375)
,p_script_id=>wwv_flow_imp.id(3293473959760495371)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'PKG_AUTH'
,p_last_updated_by=>'MOREIRA.MSM'
,p_last_updated_on=>to_date('20230320134108','YYYYMMDDHH24MISS')
,p_created_by=>'MOREIRA.MSM'
,p_created_on=>to_date('20230320134108','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
