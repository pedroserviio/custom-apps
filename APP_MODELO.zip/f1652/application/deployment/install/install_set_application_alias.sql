prompt --application/deployment/install/install_set_application_alias
begin
--   Manifest
--     INSTALL: INSTALL-set application alias
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2455427484424898612)
,p_install_id=>wwv_flow_imp.id(3482772300682272234)
,p_name=>'set application alias'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_name VARCHAR(255);',
'BEGIN',
'',
'    l_name := apex_application_install.get_application_name;',
'',
'    APEX_APPLICATION_INSTALL.SET_APPLICATION_ALIAS(',
'        p_application_alias => REGEXP_REPLACE(l_name, ''[^a-zA-Z]'')',
'    );',
'',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
