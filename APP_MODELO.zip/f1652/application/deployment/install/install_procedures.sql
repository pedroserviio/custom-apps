prompt --application/deployment/install/install_procedures
begin
--   Manifest
--     INSTALL: INSTALL-procedures
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3483208314773466047)
,p_install_id=>wwv_flow_imp.id(3482772300682272234)
,p_name=>'procedures'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE PROCEDURE "GET_REFRESHED_TOKEN" (refresh_token IN string)',
'IS',
'    l_blob      BLOB;',
'    l_body      CLOB;',
'BEGIN',
'    apex_web_service.g_request_headers(1).name := ''Content-Type'';',
'    apex_web_service.g_request_headers(1).value := ''application/x-www-form-urlencoded'';',
'    l_body := ''grant_type=refresh_token&client_id=apex_dev&client_secret=a57dc73f-20c7-42d2-99f6-50732790e37b&refresh_token=''||refresh_token;',
'    ',
'    l_blob := apex_web_service.make_rest_request_b(',
'        p_url            => ''http://siseg3-dev.apps.ocpdev.pf.gov.br/auth/realms/sistemasDPF/protocol/openid-connect/token'',',
'        p_http_method    => ''POST'',',
'        p_body           => l_body,',
'        p_transfer_timeout => 3600',
'    );',
'    apex_json.parse(TO_CHAR(l_blob));',
'    apex_util.set_session_state(''G_REFRESH_TOKEN'', apex_json.get_varchar2(''refresh_token''));',
'    apex_util.set_session_state(''G_TOKEN_CODED'', (''Bearer '' || apex_json.get_varchar2(''access_token'')));',
'    apex_util.set_session_state(''G_TOKEN_TIME'', TO_CHAR(TO_CHAR(sysdate,''sssss'')));',
'END;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE PROCEDURE "GET_USER" (user IN STRING)',
'IS',
'    access_token    STRING(32767);',
'    l_blob          BLOB;',
'    r_json          STRING(32767);',
'BEGIN',
'    access_token := SUBSTR(apex_util.get_session_state(''G_TOKEN_CODED''), 7);',
'    l_blob := apex_web_service.make_rest_request_b(',
'          p_url            => ''http://corporativo-rest-corporativo-rest-dev.apps.ocpdev.pf.gov.br/corporativo/api/usuarios/''||user||''?access_token=''||access_token,',
'          p_http_method    => ''GET'',',
'          p_transfer_timeout => 3600',
'    );',
'    ',
'    r_json := TO_CHAR(l_blob);',
'    apex_json.parse(r_json);',
'    apex_util.set_session_state(''G_CPF'', apex_json.get_varchar2(''dadosPessoais.cpfCnpj''));',
'    apex_util.set_session_state(''G_LOTACAO_USER'', apex_json.get_varchar2(''unidadeExercicio.sigla''));',
'    apex_util.set_session_state(''G_USER_JSON'', r_json);',
'END;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3483208336610466048)
,p_script_id=>wwv_flow_imp.id(3483208314773466047)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'GET_REFRESHED_TOKEN'
,p_last_updated_by=>'MOREIRA.MSM'
,p_last_updated_on=>to_date('20221101152823','YYYYMMDDHH24MISS')
,p_created_by=>'MOREIRA.MSM'
,p_created_on=>to_date('20221101152823','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3483208550561466048)
,p_script_id=>wwv_flow_imp.id(3483208314773466047)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'GET_USER'
,p_last_updated_by=>'MOREIRA.MSM'
,p_last_updated_on=>to_date('20221101152823','YYYYMMDDHH24MISS')
,p_created_by=>'MOREIRA.MSM'
,p_created_on=>to_date('20221101152823','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
