prompt --application/deployment/install/install_create_credentials
begin
--   Manifest
--     INSTALL: INSTALL-create credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2344062942639967153)
,p_install_id=>wwv_flow_imp.id(3482751877698250933)
,p_name=>'create credentials'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    workspace_name VARCHAR(50);',
'BEGIN',
'',
'    SELECT workspace INTO workspace_name FROM APEX_WORKSPACES;',
'    apex_util.set_workspace(p_workspace => workspace_name);',
'',
'    -- Create DEV credentials',
'    /*apex_credential.create_credential (',
'       p_credential_name => ''credenciais_dev'',',
'       p_credential_static_id => ''credenciais_dev'',',
'       p_authentication_type => apex_credential.C_TYPE_BASIC,',
'       p_prompt_on_install => false',
'    );*/',
'',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''credenciais_dev'',',
'        p_client_id             => ''apex_dev'',',
'        p_client_secret         => ''a57dc73f-20c7-42d2-99f6-50732790e37b'' ',
'    );',
'',
'    -- Create HOM credentials',
'    /*apex_credential.create_credential (',
'       p_credential_name => ''credenciais_hom'',',
'       p_credential_static_id => ''credenciais_hom'',',
'       p_authentication_type => apex_credential.C_TYPE_BASIC,',
'       p_prompt_on_install => false',
'    );*/',
'',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''credenciais_hom'',',
'        p_client_id             => ''apex_hom'',',
'        p_client_secret         => ''dd782ffd-c3b5-4632-9235-bb0e2fb3bcee'' ',
'    );',
'',
'    -- Create PROD credentials',
'    /*apex_credential.create_credential (',
'       p_credential_name => ''credenciais_prod'',',
'       p_credential_static_id => ''credenciais_prod'',',
'       p_authentication_type => apex_credential.C_TYPE_BASIC,',
'       p_prompt_on_install => false',
'    );*/',
'',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''credenciais_prod'',',
'        p_client_id             => ''apex_prod'',',
'        p_client_secret         => ''f6fc688b-a2eb-48e6-964d-cd6556ede0ca'' ',
'    );',
'    COMMIT;',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
