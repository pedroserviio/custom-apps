prompt --application/deployment/install/install_functions
begin
--   Manifest
--     INSTALL: INSTALL-functions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3483207609173464167)
,p_install_id=>wwv_flow_imp.id(3482772300682272234)
,p_name=>'functions'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE FUNCTION "CALC_TIME" (argTimestamp NUMBER)',
'RETURN NUMBER',
'IS currentTime NUMBER := TO_CHAR(sysdate,''sssss'');',
'BEGIN',
'    RETURN  currentTime - argTimestamp;',
'END;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "SISEG_AUTHORIZATION" ',
'(p_role in VARCHAR2) ',
'return BOOLEAN ',
'is ',
'    l_numroles  NUMBER; ',
'begin ',
'    apex_debug.message(''G_ACCESS_TOKEN_PAYLOAD ----> '' || apex_util.get_session_state(''G_ACCESS_TOKEN_PAYLOAD'')); ',
'    apex_json.parse(apex_util.get_session_state(''G_ACCESS_TOKEN_PAYLOAD'')); ',
unistr('    -- se n\00E3o possui roles para o nosso aplicativo, retorno false '),
'    if apex_json.does_exist(p_path=>''resource_access.apex_dev.roles'') = FALSE then ',
unistr('        apex_debug.message(''n\00E3o tem roles''); '),
'        return false; ',
'    end if; ',
unistr('    -- percorro array de roles at\00E9 encontrar a role desejada '),
'    l_numroles := apex_json.get_count(p_path=>''resource_access.apex_dev.roles''); ',
'    for i in 1 .. l_numroles loop ',
'        apex_debug.message(''encontrada role '' || apex_json.get_varchar2(''resource_access.apex_dev.roles[%d]'', i)); ',
'        if p_role = apex_json.get_varchar2(''resource_access.apex_dev.roles[%d]'', i) then ',
'            return TRUE; ',
'        end if; ',
'    end loop; ',
unistr('    -- n\00E3o encontrou role, false '),
'    return FALSE; ',
'end;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3483207625835464169)
,p_script_id=>wwv_flow_imp.id(3483207609173464167)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CALC_TIME'
,p_last_updated_by=>'MOREIRA.MSM'
,p_last_updated_on=>to_date('20221101152804','YYYYMMDDHH24MISS')
,p_created_by=>'MOREIRA.MSM'
,p_created_on=>to_date('20221101152804','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3483207819636464169)
,p_script_id=>wwv_flow_imp.id(3483207609173464167)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'SISEG_AUTHORIZATION'
,p_last_updated_by=>'MOREIRA.MSM'
,p_last_updated_on=>to_date('20221101152804','YYYYMMDDHH24MISS')
,p_created_by=>'MOREIRA.MSM'
,p_created_on=>to_date('20221101152804','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
