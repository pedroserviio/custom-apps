prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 1652
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291196329303225450
,p_default_owner=>'APPMODELO'
);
null;
wwv_flow_imp.component_end;
end;
/
