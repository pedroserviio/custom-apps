prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_imp.id(3378832024886223726)
,p_name=>'reCAPTCHA'
,p_alias=>'RECAPTCHA'
,p_step_title=>'reCAPTCHA'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>'<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onloadTurnstileCallback" defer></script>'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const btnSubmit = document.getElementById(''btnSubmit'');',
'btnSubmit.disabled = true;',
'',
'window.onloadTurnstileCallback = function () {',
'    turnstile.render(''#id_cloudflare'', {',
'        sitekey: ''0x4AAAAAAAIQmzynvcc6xGQw'',',
'        callback: function(token) {',
'            console.log(`Challenge Success ${token}`);',
'            ',
'            //seta o codigo',
'            apex.item(''P8_RESPONSE'').setValue(token);',
unistr('            //Come\00E7a a chamada process'),
'',
'            apex.server.process("CLOUDFLARE",',
'					{pageItems: ''#P8_RESPONSE''},',
'					{dataType: ''json'', loadingIndicatorPosition: ''page'', ',
'                    success: function(data){',
'                    //verifica se o cloudflare conseguiu resolver o desafio',
'                        if (data.erro == ''S''){',
'                            alert(''Erro no reCAPTCHA!'');',
'                        }else{',
'                            apex.message.showPageSuccess(''reCAPTCHA sucedido!'');',
'                            btnSubmit.disabled = false;',
'                        }',
'                    },',
'                    error: function (jqXHR, textStatus, errorThrown) {',
'',
'                        apex.message.clearErrors();',
'                        apex.message.showErrors([',
'                            {type: ''error'',',
'                            location: ''page'',',
'                            message: ''Ocorreu um erro. Entre em contato com o administrador!'',',
'                            unsafe: false',
'                            }',
'                        ]);',
'',
unistr('                        // Limpar erro ap\00F3s 5 segundos.'),
'                        setTimeout(function() {',
'                            apex.message.clearErrors();',
'                        }, 5000); // 3 seconds delay',
'',
'                    }',
'                    ',
'                }',
'            );',
'            //Termina chamada process',
'        },',
'    });',
'};',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'PEDRO.PVSM'
,p_last_upd_yyyymmddhh24miss=>'20230911151729'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136133594319279065)
,p_plug_name=>'reCAPTCHA - CLOUDFLARE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136134339745279072)
,p_plug_name=>'CLOUDFLARE'
,p_region_name=>'id_cloudflare'
,p_parent_plug_id=>wwv_flow_imp.id(4136133594319279065)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136134511362279074)
,p_plug_name=>'Buttons Container'
,p_parent_plug_id=>wwv_flow_imp.id(4136133594319279065)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(3378683146583223653)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136133955903279068)
,p_plug_name=>unistr('Instru\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378698965178223659)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p><strong>Tutorial para implementa\00E7\00E3o do reCAPTCHA da CloudFlare</strong></p>'),
'<a href="#APP_FILES#RECAPTCHA APEX.pdf" target="_blank" style="color: blue; border-bottom: 1px solid blue"> reCAPTCHA</a>',
'',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136134715164279076)
,p_plug_name=>'RECAPTCHA - GOOGLE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_imp.id(3378643359578223627)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136134824842279077)
,p_plug_name=>'GOOGLE'
,p_parent_plug_id=>wwv_flow_imp.id(4136134715164279076)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="g-recaptcha" data-sitekey="6Le9QFkUAAAAAEtyzsbIZUcFbq8pT4KvKghL6Zb0"></div>',
'<script src="https://www.google.com/recaptcha/api.js" async defer></script>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4136134941663279078)
,p_plug_name=>'Buttons Container'
,p_parent_plug_id=>wwv_flow_imp.id(4136134715164279076)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(3378683146583223653)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4168576031704675339)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3378746822636223676)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3378643974083223628)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3378808979511223707)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4136134614537279075)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4136134511362279074)
,p_button_name=>'SUBMIT'
,p_button_static_id=>'btnSubmit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3378807365124223706)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'SUBMIT'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4136135064026279079)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4136134941663279078)
,p_button_name=>'SUBMIT_2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3378807365124223706)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'SUBMIT'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4136134434324279073)
,p_name=>'P8_RESPONSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4136134339745279072)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4136135322796279082)
,p_name=>'P8_RESPONSE_GOOGLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4136134824842279077)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4136135160172279080)
,p_name=>'reCAPTCHA'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4136135064026279079)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
,p_required_patch=>wwv_flow_imp.id(3378643359578223627)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4136135234737279081)
,p_event_id=>wwv_flow_imp.id(4136135160172279080)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P8_RESPONSE_GOOGLE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'grecaptcha.getResponse();'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4136135444550279083)
,p_event_id=>wwv_flow_imp.id(4136135160172279080)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("GOOGLE",',
'	                {pageItems: ''#P8_RESPONSE_GOOGLE''},',
'					{dataType: ''json'', loadingIndicatorPosition: ''page'', ',
'                        success: function(data){',
'                        ',
'                            apex.message.clearErrors();',
'                        ',
'                            if (data.erro == ''S''){',
'                                alert(''Erro no reCAPTCHA!'');',
'                            }else{',
'                                apex.message.showPageSuccess(''reCAPTCHA - Google sucedido!'');',
'                            }',
'',
'                        },',
'                        error: function (jqXHR, textStatus, errorThrown) {',
'',
'                            apex.message.clearErrors();',
'                            apex.message.showErrors([',
'                                {type: ''error'',',
'                                location: ''page'',',
'                                message: ''Ocorreu um erro. Entre em contato com o administrador!'',',
'                                unsafe: false',
'                                }',
'                            ]);',
'',
unistr('                            // Limpar erro ap\00F3s 5 segundos.'),
'                            setTimeout(function() {',
'                                apex.message.clearErrors();',
'                            }, 5000); // 3 seconds delay',
'',
'                        }',
'',
'			        }',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4136133838669279067)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CLOUDFLARE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'	v_error varchar(1);',
'	v_error_msg varchar(100);',
'    v_remote_ip varchar(30);',
'    v_uuid varchar(150);',
'	',
'    e_error exception;',
'    l_secret  VARCHAR2(100) := ''0x4AAAAAAAIQm8qqlP0nQTO8kJB_L23LPf0'';',
'    l_blob    BLOB;',
'    l_json    JSON_OBJECT_T;',
'    l_body    CLOB;',
'',
'    l_clob CLOB;',
'    r_json STRING(32767);',
'',
'BEGIN',
'    apex_json.open_object;',
'    apex_debug.enable(); ',
'    ',
'    select owa_util.get_cgi_env(''REMOTE_ADDR'') INTO v_remote_ip from dual;',
'    select SYS_GUID() into v_uuid from dual;',
'',
'    apex_web_service.g_request_headers(1).name := ''Content-Type'';',
'    apex_web_service.g_request_headers(1).value := ''application/x-www-form-urlencoded'';',
'    l_body := ''secret='' || l_secret || ''&response='' || :P8_RESPONSE || ''&remoteip='' || v_remote_ip || ''&idempotency_key='' || v_uuid;',
'',
'    apex_debug.message(''antes chamada web'');',
'    apex_debug.message(l_body);',
'    ',
'    l_clob := apex_web_service.make_rest_request(',
'        p_url            => ''https://challenges.cloudflare.com/turnstile/v0/siteverify'',',
'        p_http_method    => ''POST'',',
'        p_body           => l_body,',
'        p_transfer_timeout => 3600       ',
'    );',
'',
'    apex_debug.message(''antes convert blob'');',
'    ',
'    --Convert the BLOB to a CLOB',
'    --l_clob := to_clob(l_blob);',
'    apex_debug.message(''ABC: '' || l_clob);',
'',
'    apex_debug.message(''antes parse json'');',
'    ',
'    -- Parse the CLOB as a JSON object',
'    l_json := json_object_t.parse(l_clob);',
'',
'    IF (l_json.get_string(''success'') = ''true'') THEN',
'',
'        apex_json.write(''erro'', ''N'');',
'		apex_json.write(''msg'', ''Ok!'');',
'',
'    ELSE',
'        apex_json.write(''erro'', ''S'');',
'		apex_json.write(''msg'', ''Erro no RECAPTCHA!'');',
'    END IF;',
'',
'	apex_json.close_object;',
'',
'    ',
' EXCEPTION',
'    WHEN others THEN',
'        apex_debug.message(''No EXCEPTION'');',
'		apex_json.write(''erro'', ''S'', true);',
unistr('        apex_json.write(''msg'', ''Sistema indispon\00EDvel temporariamente!'');'),
'		apex_json.close_object;',
'        raise e_error;',
'',
' END;',
'',
''))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4136135577877279084)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GOOGLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'	v_error varchar(1);',
'	v_error_msg varchar(100);',
'	',
'    e_error exception;',
'    l_response  VARCHAR2(4000);',
'    p_url  VARCHAR2(256);',
'    l_secret    VARCHAR2(100) := ''6Le9QFkUAAAAAG_3MBCIxdDEbGw7iENHD2sqYCrl'';',
'    l_blob    BLOB;',
'    l_json    JSON_OBJECT_T;',
'    l_body    CLOB;',
'',
'    l_clob CLOB;',
'    r_json STRING(32767);',
'',
'BEGIN',
'',
'	v_error := ''N'';',
'	v_error_msg := null;',
'	',
'	IF v_error != ''S'' THEN',
'',
'        apex_debug.enable(); ',
'        apex_json.open_object;',
'',
'        apex_web_service.g_request_headers(1).name := ''Content-Type'';',
'        apex_web_service.g_request_headers(1).value := ''application/x-www-form-urlencoded'';',
'        l_body := ''secret='' || l_secret || ''&response='' || :P8_RESPONSE_GOOGLE;',
'',
'        l_blob := apex_web_service.make_rest_request_b(',
'            p_url            => ''https://www.google.com/recaptcha/api/siteverify'',',
'            p_http_method    => ''POST'',',
'            p_body           => l_body,',
'            p_transfer_timeout => 3600       ',
'        );',
'',
'        -- Convert the BLOB to a CLOB',
'        l_clob := to_clob(l_blob);',
'        ',
'        -- Parse the CLOB as a JSON object',
'        l_json := json_object_t.parse(l_clob);',
'        ',
'        IF (l_json.get_string(''success'') = ''true'') THEN',
'',
'            apex_json.write(''erro'', ''N'');',
'    		apex_json.write(''msg'', ''Ok!'');',
'',
'        ELSE',
'            apex_json.write(''erro'', ''S'');',
'    		apex_json.write(''msg'', ''Erro no RECAPTCHA!'');',
'        END IF;',
'',
'		apex_json.close_object;',
'',
'	ELSE',
'	',
'		apex_json.open_object;',
'		apex_json.write(''erro'', ''S'', true);',
'		apex_json.write(''msg'', v_error_msg, true);',
'		apex_json.close_object;',
'	',
'	END IF;',
'    ',
' EXCEPTION',
'    WHEN others THEN',
'        apex_debug.message(''No EXCEPTION'');',
'		apex_json.open_object;',
'		apex_json.write(''erro'', ''S'', true);',
unistr('        apex_json.write(''msg'', ''Sistema indispon\00EDvel temporariamente!'');'),
'		apex_json.close_object;',
' END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(3378643359578223627)
);
wwv_flow_imp.component_end;
end;
/
