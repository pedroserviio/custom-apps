prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1258205614520819407
,p_default_application_id=>1652
,p_default_id_offset=>3291175906319204149
,p_default_owner=>'APPMODELO'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_imp.id(3378832024886223726)
,p_name=>'Exemplo Upload Arquivo'
,p_alias=>'EXEMPLO-UPLOAD-ARQUIVO'
,p_step_title=>'Exemplo Upload Arquivo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'10'
,p_last_updated_by=>'DIAS.FDA'
,p_last_upd_yyyymmddhh24miss=>'20230905115624'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3772914944079918391)
,p_plug_name=>'Upload Arquivo'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3772915211876918394)
,p_plug_name=>'Processamento Download'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3378734723387223672)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_mime_type     TB_ARQUIVO.MIME_TYPE%TYPE;',
'v_no_arquivo    TB_ARQUIVO.NO_ARQUIVO%TYPE;',
'v_count         NUMBER;',
'v_path          VARCHAR(200) := ''SINACTI2'';',
'',
'BEGIN',
'',
'SELECT COUNT(*) INTO v_count FROM TB_ARQUIVO WHERE ID_ARQUIVO = :P7_ID_ARQUIVO_HIDDEN;',
'',
'IF v_count > 0 THEN',
'    SELECT NO_ARQUIVO, MIME_TYPE INTO v_no_arquivo, v_mime_type FROM TB_ARQUIVO WHERE ID_ARQUIVO = :P7_ID_ARQUIVO_HIDDEN;',
'    HTP.P(''<a href="''||APEX_UTIL.PREPARE_URL(APEX_PAGE.GET_URL (p_page => 9, p_session => :APP_SESSION, p_request => ''EDIT'', p_debug => :DEBUG, p_clear_cache => 7,   p_items => ''P9_NO_ARQUIVO,P9_MIME_TYPE'',  p_values => v_no_arquivo||'',''||v_mime_type'
||' ))||''" style="text-decoration: underline">'');',
'    HTP.P(v_no_arquivo);',
'    HTP.P(''</a>'');',
'ELSE',
unistr('    HTP.P(''<span>N\00E3o existem anexos salvos</span>'');'),
'END IF;',
'',
'END;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4153739890716285731)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3378746822636223676)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3378643974083223628)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3378808979511223707)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4154179301141382349)
,p_button_sequence=>20
,p_button_name=>'Upload'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3378807365124223706)
,p_button_image_alt=>'Upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3772915021833918392)
,p_name=>'P7_ID_ARQUIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3772914944079918391)
,p_prompt=>'Upload de Anexo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3378804818425223704)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3772915361473918395)
,p_name=>'P7_ID_ARQUIVO_HIDDEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3772914944079918391)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4154179476274382350)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Salvar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'i_id_anexo NUMBER;',
'l_blob     BLOB;',
'l_mime     VARCHAR2(120);',
'l_file_name VARCHAR2(120);',
'BEGIN',
'',
'   SELECT blob_content, mime_type, filename INTO l_blob, l_mime, l_file_name FROM APEX_APPLICATION_TEMP_FILES WHERE name = :P7_ID_ARQUIVO;',
'   INSERT INTO TB_ARQUIVO (ID_ARQUIVO,NO_ARQUIVO, MIME_TYPE, DOC_BLOB) VALUES (null, l_file_name, l_mime, l_blob) RETURNING ID_ARQUIVO INTO i_id_anexo;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4154179301141382349)
);
wwv_flow_imp.component_end;
end;
/
